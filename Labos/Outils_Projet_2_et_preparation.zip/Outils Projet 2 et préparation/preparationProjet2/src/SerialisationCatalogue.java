

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;


public class SerialisationCatalogue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//S�rialisation du catalogue
		

	}

}
