import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class DeserialisationCatalogue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
  // d�s�rialiser le catalogue
	
	
	}
}
